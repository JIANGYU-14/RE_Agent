from __future__ import annotations

import os
from dataclasses import dataclass


@dataclass(frozen=True)
class Settings:
    project_name: str = "VeADK PaperAgent Backend"
    agentkit_base_url: str = ""
    agentkit_api_key: str = ""
    database_url: str = ""


settings = Settings(
    agentkit_base_url=os.getenv("AGENTKIT_BASE_URL", ""),
    agentkit_api_key=os.getenv("AGENTKIT_API_KEY", ""),
    database_url=os.getenv("DATABASE_URL", ""),
)
