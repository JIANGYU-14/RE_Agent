from fastapi import FastAPI
from app.api import sessions, chat, history
from app.core.db import init_db

app = FastAPI()


@app.on_event("startup")
def on_startup():
    init_db()


app.include_router(sessions.router, prefix="/api")
app.include_router(chat.router, prefix="/api")
app.include_router(history.router, prefix="/api")
