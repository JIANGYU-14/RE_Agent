from sqlalchemy import create_engine
from sqlalchemy.engine import Engine

from app.config import settings
from app.repositories.messages_repo import metadata as messages_metadata
from app.repositories.sessions_repo import metadata as sessions_metadata


_engine: Engine | None = None


def get_engine() -> Engine:
    global _engine

    if _engine is None:
        if not settings.database_url:
            raise RuntimeError(
                "DATABASE_URL 未配置：请在启动前设置环境变量 DATABASE_URL，例如 sqlite:///./dev.db 或 postgresql://user:pass@host:5432/db"
            )

        _engine = create_engine(
            settings.database_url,
            pool_pre_ping=True,
            pool_size=10,
            max_overflow=20,
        )

    return _engine


def init_db() -> None:
    engine = get_engine()
    messages_metadata.create_all(engine)
    sessions_metadata.create_all(engine)
