from fastapi import APIRouter, Header, Depends, HTTPException
from pydantic import BaseModel
from typing import List, Dict, Any

import os
import requests

from app.core.agentkit_client import AgentKitClient
from app.repositories.messages_repo import MessagesRepo
from app.repositories.sessions_repo import SessionsRepo
from app.core.db import get_engine
from app.services.session_title import async_generate


router = APIRouter()
agent = AgentKitClient()


# ---------- request / response models ----------

class ChatRequest(BaseModel):
    session_id: str
    text: str


class ChatResponse(BaseModel):
    answer: str
    parts: List[Dict[str, Any]]


# ---------- dependencies ----------

def get_messages_repo() -> MessagesRepo:
    return MessagesRepo(get_engine())


def get_sessions_repo() -> SessionsRepo:
    return SessionsRepo(get_engine())


# ---------- api ----------

@router.post("/chat", response_model=ChatResponse)
def chat(
    payload: ChatRequest,
    authorization: str = Header(...),
    messages_repo: MessagesRepo = Depends(get_messages_repo),
    sessions_repo: SessionsRepo = Depends(get_sessions_repo),
):
    session_id = payload.session_id
    user_text = payload.text

    # 1️⃣ save user message
    messages_repo.save_message(
        session_id=session_id,
        role="user",
        parts=[
            {
                "type": "text",
                "content": user_text,
            }
        ],
    )

    sessions_repo.touch_session(session_id)

    try:
        agent_text = agent.send(
            session_id=session_id,
            text=user_text,
        )
    except requests.exceptions.Timeout:
        raise HTTPException(status_code=504, detail="Agent 服务响应超时")
    except requests.exceptions.RequestException:
        raise HTTPException(status_code=502, detail="Agent 服务调用失败")

    max_chars_raw = os.getenv("CHAT_MAX_ASSISTANT_CHARS", "")
    max_chars = 0
    if max_chars_raw:
        try:
            max_chars = int(max_chars_raw)
        except ValueError:
            max_chars = 0

    truncated = False
    original_len = len(agent_text)
    if max_chars > 0 and original_len > max_chars:
        agent_text = agent_text[:max_chars]
        truncated = True

    assistant_parts = [
        {
            "type": "text",
            "content": agent_text,
            "metadata": (
                {"truncated": True, "original_length": original_len, "max_chars": max_chars}
                if truncated
                else None
            ),
        }
    ]

    messages_repo.save_message(
        session_id=session_id,
        role="assistant",
        parts=assistant_parts,
    )

    sessions_repo.touch_session(session_id)
    async_generate(session_id)

    return {
        "answer": agent_text,
        "parts": assistant_parts,
    }
